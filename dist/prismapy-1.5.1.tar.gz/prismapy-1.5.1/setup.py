import setuptools


setuptools.setup(
    name='prismapy', 
    version='1.5.1',                         
    packages=setuptools.find_packages(),
    author="Uzay-G",
    url="https://github.com/Uzay-G/prisma.py"           
)
