# Prisma.py

Simple wrapper for Prismanalytics Discord bot analytics that interfaces with `discord.py`. 

